import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo1';
  imageName: string="../assets/pic1.JPG";

  changeUsername(): void{
    this.title = 'prasad';
  }

  toggleImage(): void{
    this.imageName = this.imageName == "../assets/pic1.JPG" ? "../assets/pic2.JPG" : "../assets/pic1.JPG";
  }
}

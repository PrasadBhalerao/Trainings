export class Employee { 
    empNo: number;
    email: string;
    salary: number;
    constructor(){
    }
}
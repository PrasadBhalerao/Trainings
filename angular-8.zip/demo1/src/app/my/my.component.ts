import { Component, 
  OnInit
 } from '@angular/core';

 import { Employee } from '../emp';

@Component({
  selector: 'app-my',
  templateUrl: './my.component.html',
  styleUrls: ['./my.component.css']
})
export class MyComponent implements OnInit {
  textValue: string;
  emp: Employee = new Employee();
  empList: Array<Employee>;

  constructor() {
    this.empList = [];
   }

  ngOnInit() {
  }

  addEmployee(): void{
    this.empList.push(this.emp);
    this.emp = new Employee();
  }

  removeEmployee(i: number):void{
    this.empList.splice(i, 1);
  }

}

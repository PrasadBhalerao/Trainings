import { Component, OnInit } from '@angular/core';

import {MyService} from '../../app/my.service';

@Component({
  selector: 'app-app2',
  templateUrl: './app2.component.html',
  styleUrls: ['./app2.component.css'],
  providers:[MyService]
})
export class App2Component implements OnInit {
  counter: number;
  ngOnInit() {
  }
  constructor(private myService: MyService){}

  app2BtnClick():void{
    this.myService.increment();
    this.counter = this.myService.getCounter();
  }

}

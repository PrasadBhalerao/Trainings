import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Component({
  selector: 'app-httpdemo',
  templateUrl: './httpdemo.component.html',
  styleUrls: ['./httpdemo.component.css']
})
export class HttpdemoComponent implements OnInit {
  uid: string = "2";
  url: string = "https://reqres.in/api/users?page=";
  obj: Array<any>;
  constructor(private http: HttpClient) {

   }

  ngOnInit() {
  }

  getUser(pageId: number){
    console.log("info: " + this.uid);
    this.http.get(this.url + pageId.toString()).subscribe((success) => {
      this.obj = success["data"];
    },
    (error) => {
      this.obj = error;
    });
  }

}

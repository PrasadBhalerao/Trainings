import { Component } from '@angular/core';

import {MyService} from '../app/my.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  counter: number;
  constructor(private myService: MyService){}

  appBtnClick():void{
    this.myService.increment();
    this.counter = this.myService.getCounter();
  }
}

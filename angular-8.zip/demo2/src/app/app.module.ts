import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule } from '@angular/forms'

import { AppComponent } from './app.component';
import { App2Component } from './app2/app2.component';
import { App3Component } from './app3/app3.component';
import { MyService } from './my.service';
import { HttpdemoComponent } from './httpdemo/httpdemo.component';

@NgModule({
  declarations: [
    AppComponent,
    App2Component,
    App3Component,
    HttpdemoComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [MyService],
  bootstrap: [HttpdemoComponent]
 // bootstrap: [AppComponent]
})
export class AppModule { }

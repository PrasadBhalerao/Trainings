import { Component, OnInit } from '@angular/core';


import {MyService} from '../../app/my.service';

@Component({
  selector: 'app-app3',
  templateUrl: './app3.component.html',
  styleUrls: ['./app3.component.css']
})
export class App3Component implements OnInit {
  counter: number;
  ngOnInit(){

  }

  constructor(private myService: MyService){}

  app3BtnClick():void{
    this.myService.increment();
    this.counter = this.myService.getCounter();
  }
}

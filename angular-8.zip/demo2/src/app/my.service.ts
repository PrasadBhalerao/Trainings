import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyService {
  counter: number = 0;
  constructor() {
    console.log('in my service');
   }

  increment():void{
    this.counter += 1;
  }

  getCounter():number{
    return this.counter;
  }
}

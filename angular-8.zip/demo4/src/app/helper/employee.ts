export class Employee {
    empNo: number;
    empName: string;
    salary: number;
}

import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-form2',
  templateUrl: './form2.component.html',
  styleUrls: ['./form2.component.css']
})
export class Form2Component implements OnInit {
  employee: Employee = new Employee();
  formGroup: FormGroup;
  formControlArray = null;
  controlsObj = null;

  constructor(formBuilder: FormBuilder) {
    this.formGroup = formBuilder.group({
      "noc": new FormControl(""),
      "namec": new FormControl("", Validators.required),
      "salaryc": new FormControl("", [Validators.min(100), Validators.max(200), Validators.required]),
    });
    this.controlsObj = this.formGroup.controls;
    this.formControlArray = Object.keys(this.formGroup.controls);
  }

  ngOnInit() {
  }

  showArray(){
    console.log(this.formControlArray);
  }

}

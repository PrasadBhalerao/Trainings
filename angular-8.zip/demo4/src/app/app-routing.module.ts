import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Comp1Component } from './comp1/comp1.component';
import { Comp3Component } from './comp3/comp3.component';
import { Comp2Component } from './comp2/comp2.component';
import { CommonClass } from './CommonClass';

const routes: Routes = [
  {path:"comppath1", component: Comp1Component, canActivate: [CommonClass]},
  {path:"comppath2", component: Comp2Component, canActivate: [CommonClass]},
  {path:"comppath3", component: Comp3Component, canActivate: [CommonClass]},
  {
    path:"comppath4", 
    loadChildren: './helper/helper.module#HelperModule',
    canActivate: [CommonClass]
  } //() => import('./helper/helper.module').then(x => x.HelperModule)
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule],
  providers: [CommonClass]
})
export class AppRoutingModule { }

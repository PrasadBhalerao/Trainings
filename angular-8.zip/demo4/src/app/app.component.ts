import { Component, Output, EventEmitter } from '@angular/core';
import { CommonClass } from './CommonClass';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  username: string;
  isUserNameValid: boolean;
  checkValidity(){
    this.isUserNameValid = this.username.length > 1;
    CommonClass.isAuthenticated = this.isUserNameValid;
  }
}

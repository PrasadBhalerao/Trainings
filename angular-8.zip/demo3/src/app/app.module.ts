import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HelperModule } from './helper/helper.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule, HelperModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

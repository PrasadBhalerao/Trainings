import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.css']
})
export class MarksComponent implements OnInit {
  name: string;
  marks: number;
  constructor() { }

  ngOnInit() {
  }

  myEventHandler(str: string){
    alert(str);
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MarksComponent } from './marks/marks.component';
import { GradeComponent } from './grade/grade.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [MarksComponent, GradeComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [MarksComponent, GradeComponent]
})
export class HelperModule { }

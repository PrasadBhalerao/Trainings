import { Component, 
  OnInit,
  Input,
  OnChanges,
  SimpleChanges,
  EventEmitter,
  Output
} from '@angular/core';

@Component({
  selector: 'app-grade',
  template: "{{grade}} for {{marks}}",
  styleUrls: ['./grade.component.css']
})
export class GradeComponent implements OnInit, OnChanges {  
  grade: string;
  @Input() marks: number;
  @Output() myEvent: EventEmitter<String> = new EventEmitter<String>();
  
  constructor() {
  }

  ngOnInit() {
  }
  
  ngOnChanges(changes: SimpleChanges): void {
    this.calcGrade(changes);
  }

  calcGrade(changes: SimpleChanges) : void{
    console.log(changes);
    if(this.marks > 100){
      this.myEvent.emit('Incorrect marks - ' + this.marks);
    }
    if(this.marks >= 35)
      this.grade = "PASS"
    else
      this.grade = "FAIL"
  }

}
